﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI : MonoBehaviour
{

    private PlayerInventory inventory;
    public GameObject player;
    public Text healthtext;
    public Text ammotext;
    public Text armortext;
    // Start is called before the first frame update
    void Start()
    {
        inventory=player.GetComponent<PlayerInventory>();
    }

    // Update is called once per frame
    void Update()
    {
        healthtext.text=inventory.GetHealth().ToString();
        ammotext.text=inventory.GetWeapon().munitions.ToString();
        armortext.text=inventory.GetArmor().ToString();
    }
}
